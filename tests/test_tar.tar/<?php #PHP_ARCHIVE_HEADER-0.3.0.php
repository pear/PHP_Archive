        
        
        
        
        
        
        
        

require_once 'PHP/Archive.php';
stream_register_wrapper('phar', 'PHP_Archive');
if (!defined('PHP_ARCHIVE_COMPRESSED')) {
    define('PHP_ARCHIVE_COMPRESSED', false);
}
require_once 'phar://test.php';        
exit;
?>